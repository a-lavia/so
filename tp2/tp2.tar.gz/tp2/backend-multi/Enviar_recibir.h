#ifndef Enviar_recibir_h
#define Enviar_recibir_h

#include "Encabezado.h"

int recibir(int s, char* buf);
int enviar(int s, char* buf);


#endif