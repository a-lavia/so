# README

Para ejecutar:

1. `pip install mpi4py`
2. `mpiexec -n <num> python tp3.py` donde `<num>` indica la cantidad de nodos MPI.
