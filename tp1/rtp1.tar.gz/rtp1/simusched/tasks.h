#ifndef __TASKS_H__
#define __TASKS_H__

#include <stdlib.h>

#include "basetask.h"
void tasks_init(void);

#endif
