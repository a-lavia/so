#include "basesched.h"

using namespace std;

void SchedBase::load(int pid,int deadline) {
  load(pid);
}
